package utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
import beans.Product;
import beans.UserAccount;
 
public class DBUtils {
 
  public static UserAccount findUser(Connection conn, String userName, String password) throws SQLException {
 
      String sql = "Select a.UserName, a.Password, a.TitleOfCourtesy, a.RoleID from Employees a "
              + " where a.UserName = ? and a.password= ?";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
      pstm.setString(1, userName);
      pstm.setString(2, password);
      ResultSet rs = pstm.executeQuery();
 
      if (rs.next()) {
          String gender = rs.getString("TitleOfCourtesy");
          int roleID = rs.getInt("RoleID");
          UserAccount user = new UserAccount();
          user.setUserName(userName);
          user.setPassword(password);
          user.setGender(gender);
          user.setRoleID(roleID);
          return user;
      }
      return null;
  }
 
  public static UserAccount findUser(Connection conn, String userName) throws SQLException {
 
      String sql = "Select a.UserName, a.Password, a.TitleOfCourtesy, a.RoleID from Employees a " + " where a.UserName = ? ";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
      pstm.setString(1, userName);
 
      ResultSet rs = pstm.executeQuery();
 
      if (rs.next()) {
          String password = rs.getString("Password");
          String gender = rs.getString("TitleOfCourtesy");
          int roleID = rs.getInt("RoleID");
          UserAccount user = new UserAccount();
          user.setUserName(userName);
          user.setPassword(password);
          user.setGender(gender);
          user.setRoleID(roleID);
          return user;
      }
      return null;
  }
 
  public static List<Product> queryProduct(Connection conn) throws SQLException {
      String sql = "Select a.ProductID, a.ProductName, a.UnitPrice from Products a ";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
 
      ResultSet rs = pstm.executeQuery();
      List<Product> list = new ArrayList<Product>();
      while (rs.next()) {
          String productID = rs.getString("ProductID");
          String name = rs.getString("ProductName");
          float price = rs.getFloat("UnitPrice");
          Product product = new Product();
          product.setID(productID);
          product.setName(name);
          product.setPrice(price);
          list.add(product);
      }
      return list;
  }
 
  public static Product findProduct(Connection conn, String productID) throws SQLException {
      String sql = "Select a.ProductID, a.ProductName, a.UnitPrice from Products a where a.Code=?";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
      pstm.setString(1, productID);
 
      ResultSet rs = pstm.executeQuery();
 
      while (rs.next()) {
          String name = rs.getString("ProductName");
          float price = rs.getFloat("UnitPrice");
          Product product = new Product(productID, name, price);
          return product;
      }
      return null;
  }
 
  public static void updateProduct(Connection conn, Product product) throws SQLException {
      String sql = "Update Products set ProductName =?, UnitPrice=? where ProductID=? ";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
 
      pstm.setString(1, product.getName());
      pstm.setFloat(2, product.getPrice());
      pstm.setString(3, product.getID());
      pstm.executeUpdate();
  }
 
  public static void insertProduct(Connection conn, Product product) throws SQLException {
      String sql = "Insert into Products(ProductID, ProductName,UnitPrice) values (?,?,?)";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
 
      pstm.setString(1, product.getID());
      pstm.setString(2, product.getName());
      pstm.setFloat(3, product.getPrice());
 
      pstm.executeUpdate();
  }
 
  public static void deleteProduct(Connection conn, String productID) throws SQLException {
      String sql = "Delete Product where ProductID= ?";
 
      PreparedStatement pstm = conn.prepareStatement(sql);
 
      pstm.setString(1, productID);
 
      pstm.executeUpdate();
  }
 
}
